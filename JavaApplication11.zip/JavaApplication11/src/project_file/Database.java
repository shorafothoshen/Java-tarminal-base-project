package project_file;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Database {
    private String url = "jdbc:mysql://localhost:3306/airline_management_system";
    private String user = "root";
    private String pass = "password";
    private Connection conn;
    private Statement statement;

    // Constructor to initialize the database connection
    public Database() throws SQLException {
        conn = DriverManager.getConnection(url, user, pass);
        statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    }

    // Method to execute an INSERT, UPDATE, or DELETE query
    public int executeUpdate(String query) throws SQLException {
        return statement.executeUpdate(query);
    }
    
    Statement getStatement(){
        return statement;
    }
    
    public Connection getConnection() {
        return conn;
    }
    // Method to close the database connection
    public void close() throws SQLException {
        if (statement != null) statement.close();
        if (conn != null) conn.close();
    }
}