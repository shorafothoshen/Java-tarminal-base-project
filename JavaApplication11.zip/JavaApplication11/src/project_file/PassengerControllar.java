package project_file;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class PassengerControllar {

    public static void addNewPassenger(Database database, Scanner input) throws SQLException {
        input.nextLine();
        System.out.println("Enter Your Full Name: ");
        String name = input.nextLine();
        System.out.println("Enter Your Email: ");
        String email = input.nextLine();
        System.out.println("Enter Your Phone: ");
        String phone = input.nextLine();

        String insertQuery = "INSERT INTO Passenger (name, email, phone) VALUES ('" + name + "', '" + email + "', '" + phone + "');";
        database.executeUpdate(insertQuery);
        System.out.println("Passenger Added Successfully!!");
    }

    public static void EditPassenger(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Passenger Id (int): \n(-1 to search by name, 0 to show all passengers)");
        int id = input.nextInt();

        if (id == -1) {
            input.nextLine();
            System.out.println("Enter Passenger Name (or part of it): ");
            String name = input.nextLine();
            ArrayList<Passenger> passengers = getPassengerByName(database,name);

            if (passengers.isEmpty()) {
                System.out.println("No passenger found with the given name.");
                return;
            } else {
                System.out.println("Matching Passengers:");
                for (Passenger p : passengers) {
                    System.out.println("\nId: " + p.getId() + ",\nName: " + p.getName() + ",\nEmail: " + p.getEmail() + ",\nPhone: " + p.getPhone());
                }
                System.out.println("Enter the Passenger Id to edit:");
                id = input.nextInt();
            }
        } else if (id == 0) {
            printAllPassengers(database);
            System.out.println("Enter the Passenger Id (int):");
            id = input.nextInt();
        }

        try {
            Passenger passenger = getPassenger(database,id);

            input.nextLine();
            System.out.println("Enter Passenger Name: \n(-1 to keep old value)");
            String name = input.nextLine();
            if (name.equals("-1")) {
                name = passenger.getName();
            }

            System.out.println("Enter Passenger Email: \n(-1 to keep old value)");
            String email = input.nextLine();
            if (email.equals("-1")) {
                email = passenger.getEmail();
            }

            System.out.println("Enter Passenger Phone: \n(-1 to keep old value)");
            String phone = input.nextLine();
            if (phone.equals("-1")) {
                phone = passenger.getPhone();
            }

            passenger.setName(name);
            passenger.setEmail(email);
            passenger.setPhone(phone);

            String updateQuery = "UPDATE Passenger SET name = '" + passenger.getName() + "', email = '" + passenger.getEmail() + "', phone = '" + passenger.getPhone() + "' WHERE id = " + passenger.getId() + ";";
            database.executeUpdate(updateQuery);
            System.out.println("Successfully Edited Passenger Information!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void DeletePassenger(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Passenger Id (int): \n(-1 to search by name, 0 to show all passengers)");
        int id = input.nextInt();

        if (id == -1) {
            input.nextLine();
            System.out.println("Enter Passenger Name (or part of it): ");
            String name = input.nextLine();
            ArrayList<Passenger> passengers = getPassengerByName(database,name);

            if (passengers.isEmpty()) {
                System.out.println("No passenger found with the given name.");
                return;
            } else {
                System.out.println("Matching Passengers:");
                for (Passenger p : passengers) {
                    System.out.println("\nId: " + p.getId() + ",\nName: " + p.getName() + ",\nEmail: " + p.getEmail() + ",\nPhone: " + p.getPhone());
                }
                System.out.println("Enter the Passenger Id to delete:");
                id = input.nextInt();
            }
        } else if (id == 0) {
            printAllPassengers(database);
            System.out.println("Enter the Passenger Id to delete:");
            id = input.nextInt();
        }

        try {
            Passenger passenger = getPassenger(database,id);
            System.out.println("Passenger Found: ID = " + passenger.getId() + ", Name = " + passenger.getName());

            input.nextLine();
            System.out.println("Are you sure you want to delete this passenger? (y/n): ");
            String confirmation = input.nextLine();

            if (confirmation.equalsIgnoreCase("y")) {
                String deleteQuery = "DELETE FROM Passenger WHERE id = " + passenger.getId() + ";";
                database.executeUpdate(deleteQuery);
                System.out.println("Passenger deleted successfully.");
            } else {
                System.out.println("Deletion cancelled.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void printAllPassengers(Database database) throws SQLException {
        String query = "SELECT * FROM Passenger;";
        ResultSet rs = database.getStatement().executeQuery(query);
        System.out.println("\n--- List of All Passengers ---");
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("id"));
            System.out.println("Name: " + rs.getString("name"));
            System.out.println("Email: " + rs.getString("email"));
            System.out.println("Phone: " + rs.getString("phone"));
            System.out.println("--------------------------");
        }
    }

    public static Passenger getPassenger(Database database,int id) throws SQLException {
        String query = "SELECT * FROM Passenger WHERE id = " + id + ";";
        ResultSet rs = database.getStatement().executeQuery(query);
        if (rs.next()) {
            Passenger passenger = new Passenger();
            passenger.setId(rs.getInt("id"));
            passenger.setName(rs.getString("name"));
            passenger.setEmail(rs.getString("email"));
            passenger.setPhone(rs.getString("phone"));
            return passenger;
        } else {
            throw new SQLException("No passenger found with ID: " + id);
        }
    }

    public static ArrayList<Passenger> getPassengerByName(Database database,String name) throws SQLException {
        String query = "SELECT * FROM Passenger WHERE name LIKE '%" + name + "%';";
        ResultSet rs = database.getStatement().executeQuery(query);
        ArrayList<Passenger> passengers = new ArrayList<>();
        while (rs.next()) {
            Passenger passenger = new Passenger();
            passenger.setId(rs.getInt("id"));
            passenger.setName(rs.getString("name"));
            passenger.setEmail(rs.getString("email"));
            passenger.setPhone(rs.getString("phone"));
            passengers.add(passenger);
        }
        return passengers;
    }
}