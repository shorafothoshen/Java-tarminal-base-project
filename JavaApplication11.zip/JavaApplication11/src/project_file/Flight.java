package project_file;
import java.time.LocalDateTime;

public class Flight {
    private int id;
    private Airplane airplane;
    private Airport origin;
    private Airport destination;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
    private boolean delayed;
    private int bookedEconomy;
    private int bookedBusiness;
    private Employee[] staff;
    private Passenger[] passengers;

    public Flight() {
        delayed = false;
        staff = new Employee[10];
        bookedEconomy = 0;
        bookedBusiness = 0;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setAirplane(Airplane airplane) {
        this.airplane = airplane;
        int totalCapacity = airplane.getEconomycapacity() + airplane.getBusinesscapacity();
        passengers = new Passenger[totalCapacity];
    }

    public Airplane getAirplane() {
        return airplane;
    }

    public void setOriginAirport(Airport origin) {
        this.origin = origin;
    }

    public Airport getOriginAirport() {
        return origin;
    }

    public void setDestinationAirport(Airport destination) {
        this.destination = destination;
    }

    public Airport getDestinationAirport() {
        return destination;
    }

    public void setDepartureTime(LocalDateTime departureTime) {
        this.departureTime = departureTime;
    }

    public LocalDateTime getDepartureTime() {
        return departureTime;
    }

    public void setArrivalTime(LocalDateTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public LocalDateTime getArrivalTime() {
        return arrivalTime;
    }

    public void delay() {
        this.delayed = true;
    }

    public boolean isDelayed() {
        return delayed;
    }

    public void setBookedEconomy(int bookedEconomy) {
        this.bookedEconomy = bookedEconomy;
    }

    public int getBookedEconomy() {
        return bookedEconomy;
    }

    public void setBookedBusiness(int bookedBusiness) {
        this.bookedBusiness = bookedBusiness;
    }

    public int getBookedBusiness() {
        return bookedBusiness;
    }

    public void setStaff(Employee[] staff) { 
        this.staff = staff;
    }

    public Employee[] getStaff() {
        return staff;
    }

    public void setPassengers(Passenger[] passengers) { 
        this.passengers = passengers;
    }

    public Passenger[] getPassengers() { 
        return passengers;
    }
}
