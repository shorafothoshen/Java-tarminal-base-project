package project_file;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class AirportController {

    public static void addNewAirport(Database database, Scanner input) throws SQLException {
        input.nextLine();
        System.out.println("Enter Airport Name: ");
        String name = input.nextLine();
        System.out.println("Enter Airport City: ");
        String city = input.nextLine();

        String insertQuery = "INSERT INTO Airport (name, city) VALUES ('" + name + "', '" + city + "');";
        database.executeUpdate(insertQuery);
        System.out.println("Airport Added Successfully!!");
    }

    public static void editAirport(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Airport ID (int): \n(-1 to search by name, 0 to show all airports)");
        int id = input.nextInt();

        if (id == -1) {
            input.nextLine();
            System.out.println("Enter Airport Name (or part of it): ");
            String name = input.nextLine();
            ArrayList<Airport> airports = getAirportByName(database,name);

            if (airports.isEmpty()) {
                System.out.println("No airport found with the given name.");
                return;
            } else {
                System.out.println("Matching Airports:");
                for (Airport a : airports) {
                    System.out.println("\nId: " + a.getId() + ",\nName: " + a.getAirportName() + ",\nCity: " + a.getCity());
                }
                System.out.println("Enter the Airport ID to edit:");
                id = input.nextInt();
            }
        } else if (id == 0) {
            printAllAirports(database);
            System.out.println("Enter the Airport ID (int):");
            id = input.nextInt();
        }

        try {
            Airport airport = getAirport(database,id);

            input.nextLine();
            System.out.println("Enter Airport Name: \n(-1 to keep old value)");
            String name = input.nextLine();
            if (name.equals("-1")) {
                name = airport.getAirportName();
            }

            System.out.println("Enter Airport City: \n(-1 to keep old value)");
            String city = input.nextLine();
            if (city.equals("-1")) {
                city = airport.getCity();
            }

            airport.setAirportName(name);
            airport.setCity(city);

            String updateQuery = "UPDATE Airport SET name = '" + airport.getAirportName() + "', city = '" + airport.getCity() + "' WHERE id = " + airport.getId() + ";";
            database.executeUpdate(updateQuery);
            System.out.println("Airport Updated Successfully!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void deleteAirport(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Airport ID (int): \n(-1 to search by name, 0 to show all airports)");
        int id = input.nextInt();

        if (id == -1) {
            input.nextLine();
            System.out.println("Enter Airport Name (or part of it): ");
            String name = input.nextLine();
            ArrayList<Airport> airports = getAirportByName(database,name);

            if (airports.isEmpty()) {
                System.out.println("No airport found with the given name.");
                return;
            } else {
                System.out.println("Matching Airports:");
                for (Airport a : airports) {
                    System.out.println("\nId: " + a.getId() + ",\nName: " + a.getAirportName() + ",\nCity: " + a.getCity());
                }
                System.out.println("Enter the Airport ID to delete:");
                id = input.nextInt();
            }
        } else if (id == 0) {
            printAllAirports(database);
            System.out.println("Enter the Airport ID (int):");
            id = input.nextInt();
        }

        try {
            Airport airport = getAirport(database,id);
            System.out.println("Airport Found: ID = " + airport.getId() + ", Name = " + airport.getAirportName());

            input.nextLine();
            System.out.println("Are you sure you want to delete this airport? (y/n): ");
            String confirmation = input.nextLine();

            if (confirmation.equalsIgnoreCase("y")) {
                String deleteQuery = "DELETE FROM Airport WHERE id = " + airport.getId() + ";";
                database.executeUpdate(deleteQuery);
                System.out.println("Airport deleted successfully.");
            } else {
                System.out.println("Deletion cancelled.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void printAllAirports(Database database) throws SQLException {
        String query = "SELECT * FROM Airport;";
        ResultSet rs = database.getStatement().executeQuery(query);
        System.out.println("\n--- List of All Airports ---");
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("id"));
            System.out.println("Name: " + rs.getString("name"));
            System.out.println("City: " + rs.getString("city"));
            System.out.println("--------------------------");
        }
    }

    public static Airport getAirport(Database database,int id) throws SQLException {
        String query = "SELECT * FROM Airport WHERE id = " + id + ";";
        ResultSet rs = database.getStatement().executeQuery(query);
        if (rs.next()) {
            Airport airport = new Airport();
            airport.setId(rs.getInt("id"));
            airport.setAirportName(rs.getString("name"));
            airport.setCity(rs.getString("city"));
            return airport;
        } else {
            throw new SQLException("No airport found with ID: " + id);
        }
    }

    public static ArrayList<Airport> getAirportByName(Database database,String name) throws SQLException {
        String query = "SELECT * FROM Airport WHERE name LIKE '%" + name + "%';";
        ResultSet rs = database.getStatement().executeQuery(query);
        ArrayList<Airport> airports = new ArrayList<>();
        while (rs.next()) {
            Airport airport = new Airport();
            airport.setId(rs.getInt("id"));
            airport.setAirportName(rs.getString("name"));
            airport.setCity(rs.getString("city"));
            airports.add(airport);
        }
        return airports;
    }
}