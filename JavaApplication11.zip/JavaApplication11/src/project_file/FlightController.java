package project_file;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.PreparedStatement;

public class FlightController {
    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void AddNewFlight(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Plane id (int): \n(-1 to show all planes)");
        int planeID = input.nextInt();
        if (planeID == -1) {
            AirplaneController.printAllAirplanes(database);
            System.out.println("Enter Plane id (int):");
            planeID = input.nextInt();
        }
        Airplane plane = AirplaneController.getAirplane(database, planeID);
        
        if (plane == null) {
            System.out.println("Invalid Plane ID.");
            return;
        }

        System.out.println("Enter origin airport id (int): \n(-1 to show all airports)");
        int originId = input.nextInt();
        if (originId == -1) {
            AirportController.printAllAirports(database);
            System.out.println("Enter origin airport id (int):");
            originId = input.nextInt();
        }
        Airport origin = AirportController.getAirport(database, originId);
        
        if (origin == null) {
            System.out.println("Invalid Origin Airport ID.");
            return;
        }

        System.out.println("Enter destination airport id (int): \n(-1 to show all airports)");
        int destinationId = input.nextInt();
        if (destinationId == -1) {
            AirportController.printAllAirports(database);
            System.out.println("Enter destination airport id (int):");
            destinationId = input.nextInt();
        }
        Airport destination = AirportController.getAirport(database, destinationId);
        
        if (destination == null) {
            System.out.println("Invalid Destination Airport ID.");
            return;
        }

        if (originId == destinationId) {
            System.out.println("Origin and destination cannot be the same.");
            return;
        }

        input.nextLine(); // Clear buffer
        LocalDateTime departureTime = null;
        LocalDateTime arrivalTime = null;

        // Get departure time
        while (departureTime == null) {
            System.out.println("Enter departure time (yyyy-MM-dd HH:mm:ss): ");
            String dTime = input.nextLine();
            try {
                departureTime = LocalDateTime.parse(dTime, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date/time format. Please use yyyy-MM-dd HH:mm:ss.");
            }
        }

        // Get arrival time
        while (arrivalTime == null) {
            System.out.println("Enter arrival time (yyyy-MM-dd HH:mm:ss): ");
            String aTime = input.nextLine();
            try {
                arrivalTime = LocalDateTime.parse(aTime, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date/time format. Please use yyyy-MM-dd HH:mm:ss.");
            }
        }

        if (arrivalTime.isBefore(departureTime)) {
            System.out.println("Arrival time cannot be before departure time.");
            return;
        }

        Flight flight = new Flight();
        flight.setAirplane(plane);
        flight.setOriginAirport(origin);
        flight.setDestinationAirport(destination);
        flight.setDepartureTime(departureTime);
        flight.setArrivalTime(arrivalTime);

        ArrayList<Flight> flights = getAllFlights(database);
        int id = flights.size();
        flight.setId(id);

        // Insert flight into database
        String insertQuery = "INSERT INTO flight (airplane_id, origin_airport_id, destination_airport_id, departure_time, arrival_time, _delayed, booked_economy, booked_business) " +
                "VALUES (" + plane.getId() + ", " + origin.getId() + ", " + destination.getId() + ", '" + departureTime.format(formatter) + "', '" + arrivalTime.format(formatter) + "', false, 0, 0);";
        database.executeUpdate(insertQuery);
        System.out.println("Flight Added Successfully!!");
    }

    public static ArrayList<Flight> getAllFlights(Database database) throws SQLException {
        ArrayList<Flight> flights = new ArrayList<>();
        ArrayList<Integer> Ids = new ArrayList<>();
        ArrayList<Integer> planeIds = new ArrayList<>();
        ArrayList<Integer> originIds = new ArrayList<>();
        ArrayList<Integer> destinationIds = new ArrayList<>();
        ArrayList<LocalDateTime> departureTimes = new ArrayList<>();
        ArrayList<LocalDateTime> arrivalTimes = new ArrayList<>();
        ArrayList<Boolean> delayedList = new ArrayList<>();
        ArrayList<Integer> bookedEconomyList = new ArrayList<>();
        ArrayList<Integer> bookedBusinessList = new ArrayList<>();
        ArrayList<String> staffList = new ArrayList<>();
        ArrayList<String> passengerList = new ArrayList<>();

        String select = "SELECT * FROM flight";
        ResultSet rs = database.getStatement().executeQuery(select);

        while (rs.next()) {
            Ids.add(rs.getInt("id"));
            planeIds.add(rs.getInt("airplane_id"));
            originIds.add(rs.getInt("origin_airport_id"));
            destinationIds.add(rs.getInt("destination_airport_id"));
            departureTimes.add(LocalDateTime.parse(rs.getString("departure_time"), formatter));
            arrivalTimes.add(LocalDateTime.parse(rs.getString("arrival_time"), formatter));
            delayedList.add(rs.getBoolean("_delayed"));
            bookedEconomyList.add(rs.getInt("booked_economy"));
            bookedBusinessList.add(rs.getInt("booked_business"));
            staffList.add(rs.getString("staff")); 
            passengerList.add(rs.getString("passengers"));
        }

        rs.close();

        for (int i = 0; i < Ids.size(); i++) {
            Flight flight = new Flight();
            flight.setId(Ids.get(i));
            Airplane plane=AirplaneController.getAirplane(database, planeIds.get(i));
            flight.setAirplane(plane);
            flight.setOriginAirport(AirportController.getAirport(database, originIds.get(i)));
            flight.setDestinationAirport(AirportController.getAirport(database, destinationIds.get(i)));
            flight.setDepartureTime(departureTimes.get(i));
            flight.setArrivalTime(arrivalTimes.get(i));
            flight.setBookedEconomy(bookedEconomyList.get(i));
            flight.setBookedBusiness(bookedBusinessList.get(i));
            String st=staffList.get(i);
            String pes=passengerList.get(i);

            if (delayedList.get(i)) {
                flight.delay();
            }

            // Employee list parsing
            if (st != null && !st.isEmpty()) {
                String[] staffIds = st.split("<%%/>");
                Employee[] employees = new Employee[staffIds.length];
                for (int j = 0; j < staffIds.length; j++) {
                    employees[j] = EmployeeController.getEmployee(database, Integer.parseInt(staffIds[j]));
                }
                flight.setStaff(employees);
            }

            // Passenger list parsing
            if (pes != null && !pes.isEmpty()) {
                String[] passengerIds = pes.split("<%%/>");
                int totalCapacity=plane.getEconomycapacity()+plane.getBusinesscapacity();
                Passenger[] passengers = new Passenger[totalCapacity];
                for (int j = 0; j < passengerIds.length; j++) {
                    passengers[j] = PassengerControllar.getPassenger(database, Integer.parseInt(passengerIds[j]));
                }
                flight.setPassengers(passengers);
            }

            flights.add(flight);
        }

        return flights;
    }

    
    public static void delayFlight(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Flight id (int): \n(-1 to show all flights)");
        int id = input.nextInt();
        if (id == -1) {
            printAllFlights(database);
            System.out.println("Enter Flight id (int): ");
            id = input.nextInt();
        }

        Flight flight = getFlight(database, id);
        if (flight == null) {
            System.out.println("Flight not found!");
            return;
        }

        if (flight.isDelayed()) {
            System.out.println("Flight is already delayed.");
            return;
        }

        String update = "UPDATE flight SET _delayed = true WHERE id = " + id + ";";
        database.executeUpdate(update);
        System.out.println("Flight delayed successfully.");
    }
    
    public static Flight getFlight(Database database, int id) throws SQLException {
        Flight flight = new Flight();
        
        String select = "SELECT * FROM flight WHERE id=" + id + ";";
        PreparedStatement pstmt = database.getConnection().prepareStatement(select);
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            int ID = rs.getInt("id");
            int PlaneId = rs.getInt("airplane_id");
            int originId = rs.getInt("origin_airport_id");
            int destId = rs.getInt("destination_airport_id");
            String deptTime = rs.getString("departure_time");
            String arrTime = rs.getString("arrival_time");
            String del = rs.getString("_delayed");
            int bookedeconomy = rs.getInt("booked_economy");
            int bookedbusiness = rs.getInt("booked_business");
            String stf = rs.getString("staff");
            String pes = rs.getString("passengers");
            boolean delayed = Boolean.parseBoolean(del);
            
            flight.setId(ID);
            Airplane plane = AirplaneController.getAirplane(database, PlaneId);
            flight.setAirplane(plane);
            flight.setOriginAirport(AirportController.getAirport(database, originId));
            flight.setDestinationAirport(AirportController.getAirport(database, destId));
            LocalDateTime deparTime = LocalDateTime.parse(deptTime, formatter);
            flight.setDepartureTime(deparTime);
            flight.setArrivalTime(LocalDateTime.parse(arrTime, formatter));
            flight.setBookedEconomy(bookedeconomy);
            flight.setBookedBusiness(bookedbusiness);

            if (delayed) {
                flight.delay();
            }

            // Employee list parsing
            if (stf != null && !stf.isEmpty()) {
                String[] staffIds = stf.split("<%%/>");
                Employee[] employees = new Employee[staffIds.length];
                for (int j = 0; j < staffIds.length; j++) {
                    employees[j] = EmployeeController.getEmployee(database, Integer.parseInt(staffIds[j]));
                }
                flight.setStaff(employees);
            }

            // Passenger list parsing
            if (pes != null && !pes.isEmpty()) {
                String[] passengerIds = pes.split("<%%/>");
                int totalCapacity = plane.getEconomycapacity() + plane.getBusinesscapacity();
                Passenger[] passengers = new Passenger[totalCapacity];
                for (int j = 0; j < passengerIds.length; j++) {
                    passengers[j] = PassengerControllar.getPassenger(database, Integer.parseInt(passengerIds[j]));
                }
                flight.setPassengers(passengers);
            }
        } else {
            System.out.println("No flight found with ID: " + id);
        }

        rs.close();
        return flight;
    }

    
    public static void bookFlight(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Flight id (int): \n(-1 to show all flights)");
        int id = input.nextInt();
        if (id == -1) {
            printAllFlights(database);
            System.out.println("Enter Flight id (int): ");
            id = input.nextInt();
        }

        Flight flight = getFlight(database, id);
        if (flight == null) {
            System.out.println("Flight not found!");
            return;
        }

        Passenger passenger = null;
        System.out.println("Enter Passenger id (int): \n(-1 to get Passenger by name)");
        int passengerId = input.nextInt();
        if (passengerId == -1) {
            input.nextLine(); // Clear buffer
            System.out.println("Enter Passenger Name: ");
            String name = input.nextLine();
            ArrayList<Passenger> passengers = PassengerControllar.getPassengerByName(database, name);

            if (passengers.isEmpty()) {
                System.out.println("No passengers found with the given name.");
                return;
            } else if (passengers.size() == 1) {
                passenger = passengers.get(0);
            } else {
                System.out.println("Multiple passengers found. Please select one:");
                for (int i = 0; i < passengers.size(); i++) {
                    System.out.println((i + 1) + ". " + passengers.get(i).getName() + " (ID: " + passengers.get(i).getId() + ")");
                }
                System.out.println("Enter the number corresponding to the passenger:");
                int selection = input.nextInt();
                if (selection > 0 && selection <= passengers.size()) {
                    passenger = passengers.get(selection - 1);
                } else {
                    System.out.println("Invalid selection.");
                    return;
                }
            }
        } else {
            passenger = PassengerControllar.getPassenger(database, passengerId);
        }

        if (passenger == null) {
            System.out.println("Passenger not found!");
            return;
        }

        System.out.println("1. Economy Seats");
        System.out.println("2. Business Seats");
        System.out.println("Enter Choice (1 or 2): ");
        int choice = input.nextInt();
        System.out.println("Enter Number of Seats (int): ");
        int num = input.nextInt();

        if (choice == 1) { // Economy Seat
            flight.setBookedEconomy(flight.getBookedEconomy() + num);
        } else if (choice == 2) { // Business Seat
            flight.setBookedBusiness(flight.getBookedBusiness() + num);
        } else {
            System.out.println("Invalid choice.");
            return;
        }
       

        Passenger[] passengers = flight.getPassengers();
        for (int i = 0; i < passengers.length; i++) {
            if (passengers[i] == null) {
                passengers[i] = passenger;
                break;
            }
        }
        flight.setPassengers(passengers);


        StringBuilder sb = new StringBuilder();
        for (Passenger p : flight.getPassengers()) {
            if (p != null) {
                sb.append(p.getId()).append("<%%/>");
            }
        }
        
        String update = "UPDATE `flight` SET `booked_economy`='" +
        flight.getBookedEconomy() + "', `booked_business`='" + flight.getBookedBusiness() +
        "', `passengers`='" + sb.toString() + "' WHERE `id` = '" + flight.getId() + "';";
        database.getStatement().execute(update);
        
        System.out.println("Seats booked successfully!");
    }

  
    public static void setFlightStaff(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Flight id (int): \n(-1 to show all flights)");
        int id = input.nextInt();
        if (id == -1) {
            printAllFlights(database);
            System.out.println("Enter Flight id (int): ");
            id = input.nextInt();
        }

        Flight flight = getFlight(database, id);
        if (flight == null) {
            System.out.println("Flight not found!");
            return;
        }

        System.out.println("1. Show all employees");
        System.out.println("2. Continue");
        int j = input.nextInt();
        if (j == 1) {
            EmployeeController.printAllEmployees(database);
        }

        Employee[] employees = new Employee[10];
        for (int i = 0; i < 10; i++) {
            System.out.println("Enter Employee id " + (i + 1) + "/10:");
            int employeeId = input.nextInt();
            Employee employee = EmployeeController.getEmployee(database, employeeId);
            if (employee == null) {
                System.out.println("Employee not found! Please enter a valid Employee id.");
                i--; // Retry for the same index
            } else {
                employees[i] = employee;
            }
        }
        flight.setStaff(employees);

        // Update staff list in the database
        StringBuilder sb = new StringBuilder();
        for (Employee e : flight.getStaff()) {
            if (e != null) {
                sb.append(e.getID()).append("<%%/>");
            }
        }
        String staffUpdateQuery = "UPDATE flight SET staff = '" + sb.toString() + "' WHERE id = " + flight.getId() + ";";
        database.executeUpdate(staffUpdateQuery);

        System.out.println("Staff assigned to flight successfully!");
    }   
    
    public static void cancelFlight(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Flight id (int): \n(-1 to show all flights)");
        int id = input.nextInt();
        if (id == -1) {
            printAllFlights(database);
            System.out.println("Enter Flight id (int): ");
            id = input.nextInt();
        }

        Flight flight = getFlight(database, id);
        if (flight == null) {
            System.out.println("Flight not found!");
            return;
        }

        // Confirm cancellation
        System.out.println("Are you sure you want to cancel Flight " + flight.getId() + "? (y/n)");
        String confirmation = input.next().toLowerCase();
        if (!confirmation.equals("y")) {
            System.out.println("Flight cancellation aborted.");
            return;
        }

        // Delete or update the flight status in the database
        String deleteQuery = "DELETE FROM flight WHERE id = " + flight.getId() + ";";

        database.executeUpdate(deleteQuery); // Use deleteQuery or updateQuery based on your requirement
        System.out.println("Flight " + flight.getId() + " cancelled successfully!");
    }
    
 
public static void printFlightStaff(Database database, Scanner input) throws SQLException {
    System.out.println("Enter Flight id (int): \n(-1 to show all flights)");
    int id = input.nextInt();
    if (id == -1) {
        printAllFlights(database);
        System.out.println("Enter Flight id (int): ");
        id = input.nextInt();
    }
    Flight f = getFlight(database, id); // Load flight data from the database
    if (f == null) {
        System.out.println("Flight not found!");
        return;
    }

    // Table header for staff details
    System.out.println("\nFlight Staff Details:");
    System.out.printf("%-10s%-20s%-30s%-40s%-15s\n", "ID", "Name", "Email", "Address", "Phone");
    System.out.println("-----------------------------------------------------------------------------");

    // Printing staff details in table format
    for (Employee e : f.getStaff()) {
        if (e != null) { // Check for null values
            System.out.printf("%-10d%-20s%-30s%-40s%-15s\n", e.getID(), e.getName(), e.getEmail(), e.getAddress(), e.getPhone());
        }
    }
}

    public static void printFlightPassenger(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Flight id (int): \n(-1 to show all flights)");
        int id = input.nextInt();
        if (id == -1) {
            printAllFlights(database);
            System.out.println("Enter Flight id (int): ");
            id = input.nextInt();
        }
        Flight f = getFlight(database, id); // Load flight data from the database
        if (f == null) {
            System.out.println("Flight not found!");
            return;
        }

        // Table header for passenger details
        System.out.println("\nFlight Passenger Details:");
        System.out.printf("%-10s%-20s%-30s%-15s\n", "ID", "Name", "Email", "Phone");
        System.out.println("----------------------------------------------------------------------");

        // Printing passenger details in table format
        for (Passenger p : f.getPassengers()) {
            if (p != null) { // Check for null values
                System.out.printf("%-10d%-20s%-30s%-15s\n", p.getId(), p.getName(), p.getEmail(), p.getPhone());
            }
        }
    }


    public static void printAllFlights(Database database) throws SQLException {
        ArrayList<Flight> flights = getAllFlights(database);
        if (flights.isEmpty()) {
            System.out.println("No flights found.");
            return;
        }

        // Table header
        System.out.println("\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-5s | %-20s | %-20s | %-20s | %-20s | %-20s | %-10s | %-15s | %-15s |\n",
                "ID", "Airplane", "Origin", "Destination", "Departure Time", "Arrival Time", "Delayed", "Booked Economy", "Booked Business");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

        // Table rows
        for (Flight flight : flights) {
            System.out.printf("| %-5d | %-20s | %-20s | %-20s | %-20s | %-20s | %-10s | %-15d | %-15d |\n",
                    flight.getId(),
                    flight.getAirplane().getName(),
                    flight.getOriginAirport().getAirportName(),
                    flight.getDestinationAirport().getAirportName(),
                    flight.getDepartureTime().format(formatter),
                    flight.getArrivalTime().format(formatter),
                    flight.isDelayed() ? "Yes" : "No",
                    flight.getBookedEconomy(),
                    flight.getBookedBusiness());
        }
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
    }
    
}