package project_file;

public class Airport {
    private int id;
    private String name;
    private String city;
    Airport(){
        
    }
    public void setId(int id){
        this.id=id;
    }
    public int getId(){
        return id;
    }
    public void setAirportName(String name){
        this.name=name;
    }
    public String getAirportName(){
        return name;
    }
    public void setCity(String city){
        this.city=city;
    }
    public String getCity(){
        return city;
    }
}
