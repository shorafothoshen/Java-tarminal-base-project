package project_file;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeController {

    public static void addNewEmployee(Database database, Scanner input) throws SQLException {
        input.nextLine();
        System.out.println("Enter Employee Name: ");
        String name = input.nextLine();
        System.out.println("Enter Employee Email: ");
        String email = input.nextLine();
        System.out.println("Enter Employee Phone: ");
        String phone = input.nextLine();
        System.out.println("Enter Employee Address: ");
        String address = input.nextLine();
        System.out.println("Enter Employee Salary: ");
        double salary = input.nextDouble();

        String insertQuery = "INSERT INTO Employee (name, email, phone, address, salary) VALUES ('" + name + "', '" + email + "', '" + phone + "', '" + address + "', " + salary + ");";
        database.executeUpdate(insertQuery);
        System.out.println("Employee Added Successfully!!");
    }

    public static void editEmployee(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Employee ID (int): \n(-1 to search by name, 0 to show all employees)");
        int id = input.nextInt();

        if (id == -1) {
            input.nextLine();
            System.out.println("Enter Employee Name (or part of it): ");
            String name = input.nextLine();
            ArrayList<Employee> employees = getEmployeeByName(database,name);

            if (employees.isEmpty()) {
                System.out.println("No employee found with the given name.");
                return;
            } else {
                System.out.println("Matching Employees:");
                for (Employee e : employees) {
                    System.out.println("\nId: " + e.getID() + ",\nName: " + e.getName() + ",\nEmail: " + e.getEmail() + ",\nPhone: " + e.getPhone() + ",\nAddress: " + e.getAddress() + ",\nSalary: " + e.getSalary());
                }
                System.out.println("Enter the Employee ID to edit:");
                id = input.nextInt();
            }
        } else if (id == 0) {
            printAllEmployees(database);
            System.out.println("Enter the Employee ID (int):");
            id = input.nextInt();
        }

        try {
            Employee employee = getEmployee(database,id);

            input.nextLine();
            System.out.println("Enter Employee Name: \n(-1 to keep old value)");
            String name = input.nextLine();
            if (name.equals("-1")) {
                name = employee.getName();
            }

            System.out.println("Enter Employee Email: \n(-1 to keep old value)");
            String email = input.nextLine();
            if (email.equals("-1")) {
                email = employee.getEmail();
            }

            System.out.println("Enter Employee Phone: \n(-1 to keep old value)");
            String phone = input.nextLine();
            if (phone.equals("-1")) {
                phone = employee.getPhone();
            }

            System.out.println("Enter Employee Address: \n(-1 to keep old value)");
            String address = input.nextLine();
            if (address.equals("-1")) {
                address = employee.getAddress();
            }

            System.out.println("Enter Employee Salary: \n(-1 to keep old value)");
            double salary = input.nextDouble();
            if (salary == -1) {
                salary = employee.getSalary();
            }

            employee.setName(name);
            employee.setEmail(email);
            employee.setPhone(phone);
            employee.setAddress(address);
            employee.setSalary(salary);

            String updateQuery = "UPDATE Employee SET name = '" + employee.getName() + "', email = '" + employee.getEmail() + "', phone = '" + employee.getPhone() + "', address = '" + employee.getAddress() + "', salary = " + employee.getSalary() + " WHERE id = " + employee.getID() + ";";
            database.executeUpdate(updateQuery);
            System.out.println("Employee Updated Successfully!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void deleteEmployee(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Employee ID (int): \n(-1 to search by name, 0 to show all employees)");
        int id = input.nextInt();

        if (id == -1) {
            input.nextLine();
            System.out.println("Enter Employee Name (or part of it): ");
            String name = input.nextLine();
            ArrayList<Employee> employees = getEmployeeByName(database,name);

            if (employees.isEmpty()) {
                System.out.println("No employee found with the given name.");
                return;
            } else {
                System.out.println("Matching Employees:");
                for (Employee e : employees) {
                    System.out.println("\nId: " + e.getID() + ",\nName: " + e.getName() + ",\nEmail: " + e.getEmail() + ",\nPhone: " + e.getPhone() + ",\nAddress: " + e.getAddress() + ",\nSalary: " + e.getSalary());
                }
                System.out.println("Enter the Employee ID to delete:");
                id = input.nextInt();
            }
        } else if (id == 0) {
            printAllEmployees(database);
            System.out.println("Enter the Employee ID (int):");
            id = input.nextInt();
        }

        try {
            Employee employee = getEmployee(database,id);
            System.out.println("Employee Found: ID = " + employee.getID() + ", Name = " + employee.getName());

            input.nextLine();
            System.out.println("Are you sure you want to delete this employee? (y/n): ");
            String confirmation = input.nextLine();

            if (confirmation.equalsIgnoreCase("y")) {
                String deleteQuery = "DELETE FROM Employee WHERE id = " + employee.getID() + ";";
                database.executeUpdate(deleteQuery);
                System.out.println("Employee deleted successfully.");
            } else {
                System.out.println("Deletion cancelled.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void printAllEmployees(Database database) throws SQLException {
        String query = "SELECT * FROM Employee;";
        ResultSet rs = database.getStatement().executeQuery(query);
        System.out.println("\n--- List of All Employees ---");
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("id"));
            System.out.println("Name: " + rs.getString("name"));
            System.out.println("Email: " + rs.getString("email"));
            System.out.println("Phone: " + rs.getString("phone"));
            System.out.println("Address: " + rs.getString("address"));
            System.out.println("Salary: " + rs.getDouble("salary"));
            System.out.println("--------------------------");
        }
    }

    public static Employee getEmployee(Database database,int id) throws SQLException {
        String query = "SELECT * FROM Employee WHERE id = " + id + ";";
        ResultSet rs = database.getStatement().executeQuery(query);
        if (rs.next()) {
            Employee employee = new Employee();
            employee.setId(rs.getInt("id"));
            employee.setName(rs.getString("name"));
            employee.setEmail(rs.getString("email"));
            employee.setPhone(rs.getString("phone"));
            employee.setAddress(rs.getString("address"));
            employee.setSalary(rs.getDouble("salary"));
            return employee;
        } else {
            throw new SQLException("No employee found with ID: " + id);
        }
    }

    public static ArrayList<Employee> getEmployeeByName(Database database,String name) throws SQLException {
        String query = "SELECT * FROM Employee WHERE name LIKE '%" + name + "%';";
        ResultSet rs = database.getStatement().executeQuery(query);
        ArrayList<Employee> employees = new ArrayList<>();
        while (rs.next()) {
            Employee employee = new Employee();
            employee.setId(rs.getInt("id"));
            employee.setName(rs.getString("name"));
            employee.setEmail(rs.getString("email"));
            employee.setPhone(rs.getString("phone"));
            employee.setAddress(rs.getString("address"));
            employee.setSalary(rs.getDouble("salary"));
            employees.add(employee);
        }
        return employees;
    }
}