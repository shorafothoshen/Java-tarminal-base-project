package project_file;

public class Airplane {
    private int id;
    private String name;
    private String model;
    private int Economycapacity;
    private int Businesscapacity;

    Airplane(){
        
    }
    // Setters and Getters
    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getModel() {
        return model;
    }

    public void setEconomycapacity(int Economycapacity) {
        this.Economycapacity = Economycapacity;
    }

    public int getEconomycapacity() {
        return Economycapacity;
    }
    public void setBusinesscapacity(int Businesscapacity) {
        this.Businesscapacity = Businesscapacity;
    }

    public int getBusinesscapacity() {
        return Businesscapacity;
    }
}
