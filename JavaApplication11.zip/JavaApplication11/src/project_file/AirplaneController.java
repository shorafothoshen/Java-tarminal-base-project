package project_file;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class AirplaneController {

    public static void addNewAirplane(Database database, Scanner input) throws SQLException {
        input.nextLine();
        System.out.println("Enter Airplane Name: ");
        String name = input.nextLine();
        System.out.println("Enter Airplane Model: ");
        String model = input.nextLine();
        System.out.println("Enter Economy Class Capacity: ");
        int economyCapacity = input.nextInt();
        System.out.println("Enter Business Class Capacity: ");
        int businessCapacity = input.nextInt();

        String insertQuery = "INSERT INTO Airplane (name, model, Economycapacity, Businesscapacity) VALUES ('" + name + "', '" + model + "', " + economyCapacity + ", " + businessCapacity + ");";
        database.executeUpdate(insertQuery);
        System.out.println("Airplane Added Successfully!!");
    }
    
    public static void editAirplane(Database database, Scanner input) throws SQLException {
        System.out.println("Enter Airplane ID (int): \n(-1 to search by name, 0 to show all airplanes)");
        int id = input.nextInt();

        if (id == -1) {
            input.nextLine();
            System.out.println("Enter Airplane Name (or part of it): ");
            String name = input.nextLine();
            ArrayList<Airplane> airplanes = getAirplaneByName(database, name);

            if (airplanes.isEmpty()) {
                System.out.println("No airplane found with the given name.");
                return;
            } else {
                System.out.println("Matching Airplanes:");
                for (Airplane a : airplanes) {
                    System.out.println("\nId: " + a.getId() + ",\nName: " + a.getName() + ",\nModel: " + a.getModel() + ",\nEconomy Capacity: " + a.getEconomycapacity() + ",\nBusiness Capacity: " + a.getBusinesscapacity());
                }
                System.out.println("Enter the Airplane ID to edit:");
                id = input.nextInt();
            }
        } else if (id == 0) {
            printAllAirplanes(database);
            System.out.println("Enter the Airplane ID (int):");
            id = input.nextInt();
        }

        try {
            Airplane airplane = getAirplane(database, id);

            input.nextLine();
            System.out.println("Enter Airplane Name: \n(-1 to keep old value)");
            String name = input.nextLine();
            if (name.equals("-1")) {
                name = airplane.getName();
            }

            System.out.println("Enter Airplane Model: \n(-1 to keep old value)");
            String model = input.nextLine();
            if (model.equals("-1")) {
                model = airplane.getModel();
            }

            System.out.println("Enter Economy Capacity: \n(-1 to keep old value)");
            int economyCapacity = input.nextInt();
            if (economyCapacity == -1) {
                economyCapacity = airplane.getEconomycapacity();
            }

            System.out.println("Enter Business Capacity: \n(-1 to keep old value)");
            int businessCapacity = input.nextInt();
            if (businessCapacity == -1) {
                businessCapacity = airplane.getBusinesscapacity();
            }

            airplane.setName(name);
            airplane.setModel(model);
            airplane.setEconomycapacity(economyCapacity);
            airplane.setBusinesscapacity(businessCapacity);

            String updateQuery = "UPDATE Airplane SET name = '" + airplane.getName() + "', model = '" + airplane.getModel() + "', Economycapacity = " + airplane.getEconomycapacity() + ", Businesscapacity = " + airplane.getBusinesscapacity() + " WHERE id = " + airplane.getId() + ";";
            database.executeUpdate(updateQuery);
            System.out.println("Airplane Updated Successfully!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
     public static void deleteAirplane(Database database,Scanner input) throws SQLException {
        System.out.println("Enter Airplane ID (int): \n(-1 to search by name, 0 to show all airplanes)");
        int id = input.nextInt();

        if (id == -1) {
            input.nextLine();
            System.out.println("Enter Airplane Name (or part of it): ");
            String name = input.nextLine();
            ArrayList<Airplane> airplanes = getAirplaneByName(database,name);

            if (airplanes.isEmpty()) {
                System.out.println("No airplane found with the given name.");
                return;
            } else {
                System.out.println("Matching Airplanes:");
                for (Airplane a : airplanes) {
                    System.out.println("\nId: " + a.getId() + ",\nName: " + a.getName() + ",\nModel: " + a.getModel() + ",\nEconomy Capacity: " + a.getEconomycapacity() + ",\nBusiness Capacity: " + a.getBusinesscapacity());
                }
                System.out.println("Enter the Airplane ID to delete:");
                id = input.nextInt();
            }
        } else if (id == 0) {
            printAllAirplanes(database);
            System.out.println("Enter the Airplane ID (int):");
            id = input.nextInt();
        }

        try {
            Airplane airplane = getAirplane(database,id);
            System.out.println("Airplane Found: ID = " + airplane.getId() + ", Name = " + airplane.getName());

            input.nextLine();
            System.out.println("Are you sure you want to delete this airplane? (y/n): ");
            String confirmation = input.nextLine();

            if (confirmation.equalsIgnoreCase("y")) {
                String deleteQuery = "DELETE FROM Airplane WHERE id = " + airplane.getId() + ";";
                database.executeUpdate(deleteQuery);
                System.out.println("Airplane deleted successfully.");
            } else {
                System.out.println("Deletion cancelled.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static Airplane getAirplane(Database database, int id) throws SQLException {
        String query = "SELECT * FROM Airplane WHERE id = " + id + ";";
        ResultSet rs = database.getStatement().executeQuery(query);
        if (rs.next()) {
            Airplane airplane = new Airplane();
            airplane.setId(rs.getInt("id"));
            airplane.setName(rs.getString("name"));
            airplane.setModel(rs.getString("model"));
            airplane.setEconomycapacity(rs.getInt("Economycapacity"));
            airplane.setBusinesscapacity(rs.getInt("Businesscapacity"));
            return airplane;
        } else {
            throw new SQLException("No airplane found with ID: " + id);
        }
    }

    public static void printAllAirplanes(Database database) throws SQLException {
        String query = "SELECT * FROM Airplane;";
        ResultSet rs = database.getStatement().executeQuery(query);
        System.out.println("\n--- List of All Airplanes ---");
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("id"));
            System.out.println("Name: " + rs.getString("name"));
            System.out.println("Model: " + rs.getString("model"));
            System.out.println("Economy Capacity: " + rs.getInt("Economycapacity"));
            System.out.println("Business Capacity: " + rs.getInt("Businesscapacity"));
            System.out.println("--------------------------");
        }
    }

    public static ArrayList<Airplane> getAirplaneByName(Database database, String name) throws SQLException {
        String query = "SELECT * FROM Airplane WHERE name LIKE '%" + name + "%';";
        ResultSet rs = database.getStatement().executeQuery(query);
        ArrayList<Airplane> airplanes = new ArrayList<>();
        while (rs.next()) {
            Airplane airplane = new Airplane();
            airplane.setId(rs.getInt("id"));
            airplane.setName(rs.getString("name"));
            airplane.setModel(rs.getString("model"));
            airplane.setEconomycapacity(rs.getInt("Economycapacity"));
            airplane.setBusinesscapacity(rs.getInt("Businesscapacity"));
            airplanes.add(airplane);
        }
        return airplanes;
    }
}
