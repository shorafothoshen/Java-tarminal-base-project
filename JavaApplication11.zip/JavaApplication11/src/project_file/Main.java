package project_file;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            Database database = new Database();
            Scanner input = new Scanner(System.in);
            while (true) {
                System.out.println("\n1. Manage Passengers");
                System.out.println("2. Manage Employees");
                System.out.println("3. Manage Airplanes");
                System.out.println("4. Manage Airports");
                System.out.println("5. Manage Flight");
                System.out.println("6. View All Flights");
                System.out.println("7. Booked Flight");
                System.out.println("8. Exit");
                System.out.println("\nChoose an option:");
                int option = input.nextInt();

                switch (option) {
                    case 1:
                        managePassengers(database, input);
                        break;
                    case 2:
                        manageEmployees(database, input);
                        break;
                    case 3:
                        manageAirplanes(database, input);
                        break;
                    case 4:
                        manageAirports(database, input);
                        break;
                    case 5:
                        manageFlight(database,input);
                        break;
                    case 6:
                        FlightController.printAllFlights(database);
                        break;
                    case 7:
                        FlightController.bookFlight(database, input);
                        break;
                    case 8:
                        System.out.println("Exiting...");
                        database.close();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    private static void managePassengers(Database database, Scanner input) throws SQLException {
        while (true) {
            System.out.println("\n1. Add Passenger");
            System.out.println("2. Edit Passenger");
            System.out.println("3. Delete Passenger");
            System.out.println("4. View All Passengers");
            System.out.println("5. Back");
            System.out.println("\nChoose an option:");
            int op = input.nextInt();

            switch (op) {
                case 1:
                    PassengerControllar.addNewPassenger(database,input);
                    break;
                case 2:
                    PassengerControllar.EditPassenger(database,input);
                    break;
                case 3:
                    PassengerControllar.DeletePassenger(database,input);
                    break;
                case 4:
                    PassengerControllar.printAllPassengers(database);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageEmployees(Database database, Scanner input) throws SQLException {
        while (true) {
            System.out.println("\n1. Add Employee");
            System.out.println("2. Edit Employee");
            System.out.println("3. Delete Employee");
            System.out.println("4. View All Employees");
            System.out.println("5. Back");
            System.out.println("\nChoose an option:");
            int op = input.nextInt();

            switch (op) {
                case 1:
                    EmployeeController.addNewEmployee(database,input);
                    break;
                case 2:
                    EmployeeController.editEmployee(database,input);
                    break;
                case 3:
                    EmployeeController.deleteEmployee(database,input);
                    break;
                case 4:
                    EmployeeController.printAllEmployees(database);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageAirplanes(Database database, Scanner input) throws SQLException {
        while (true) {
            System.out.println("\n1. Add Airplane");
            System.out.println("2. Edit Airplane");
            System.out.println("3. Delete Airplane");
            System.out.println("4. View All Airplanes");
            System.out.println("5. Back");
            System.out.println("\nChoose an option:");
            int op = input.nextInt();

            switch (op) {
                case 1:
                    AirplaneController.addNewAirplane(database,input);
                    break;
                case 2:
                    AirplaneController.editAirplane(database,input);
                    break;
                case 3:
                    AirplaneController.deleteAirplane(database,input);
                    break;
                case 4:
                    AirplaneController.printAllAirplanes(database);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageAirports(Database database, Scanner input) throws SQLException {
        while (true) {
            System.out.println("\n1. Add Airport");
            System.out.println("2. Edit Airport");
            System.out.println("3. Delete Airport");
            System.out.println("4. View All Airports");
            System.out.println("5. Back");
            System.out.println("\nChoose an option:");
            int op = input.nextInt();

            switch (op) {
                case 1:
                    AirportController.addNewAirport(database,input);
                    break;
                case 2:
                    AirportController.editAirport(database,input);
                    break;
                case 3:
                    AirportController.deleteAirport(database,input);
                    break;
                case 4:
                    AirportController.printAllAirports(database);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageFlight(Database database, Scanner input) throws SQLException {
        while (true) {
            System.out.println("\n1. Add New Flight");
            System.out.println("2. Set Flight Stuff");
            System.out.println("3. Cancel Flight");
            System.out.println("4. View All Flights");
            System.out.println("5. Set Flight Staff");
            System.out.println("6. View Flight Staffs");
            System.out.println("7. View Flight Passengers");
            System.out.println("8. Back");
            System.out.println("\nChoose an option:");
            int op = input.nextInt();

            switch (op) {
                case 1:
                    FlightController.AddNewFlight(database, input);
                    break;
                case 2:
                    FlightController.setFlightStaff(database, input);
                    break;
                case 3:
                    FlightController.cancelFlight(database, input);
                    break;
                case 4:
                    FlightController.printAllFlights(database);
                    break;
                case 5:
                    FlightController.setFlightStaff(database, input);
                    break;
                case 6:
                    FlightController.printFlightStaff(database, input);
                    break;
                case 7:
                    FlightController.printFlightPassenger(database, input);
                    break;
                case 8:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}