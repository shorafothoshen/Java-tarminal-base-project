package FoodPanda;

interface OrderService {
    void placeOrder();
    double calculateTotal();
    void deliverOrder();
}